<?php
// 引入配置和工具类
require_once __DIR__ . '/inc/config.php';
require_once __DIR__ . '/inc/UrlManager.php';

// 初始化数据库连接
$db = new PDO(
    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
    DB_USER,
    DB_PASSWORD,
    [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]
);

// 初始化URL管理器
$urlManager = new UrlManager($db);

// 处理短链接生成请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['url'])) {
    $originalUrl = trim($_POST['url']);
    $customCode = isset($_POST['custom_code']) ? trim($_POST['custom_code']) : '';
    
    // 验证URL
    if (!filter_var($originalUrl, FILTER_VALIDATE_URL)) {
        $error = "请输入有效的URL";
    } else {
        try {
            // 创建短链接（自动处理重复URL）
            $shortUrl = $urlManager->createShortUrl($originalUrl, $customCode);
            $success = "短链接生成成功: <a href=\"{$shortUrl}\" target=\"_blank\">{$shortUrl}</a>";
        } catch (Exception $e) {
            $error = "生成短链接时出错: " . $e->getMessage();
        }
    }
}

// 处理短链接重定向
if (isset($_GET['id'])) {
    $shortCode = trim($_GET['id']);
    
    try {
        $urlData = $urlManager->getUrlByCode($shortCode);
        
        if ($urlData) {
            // 增加点击计数
            $urlManager->incrementClickCount($shortCode);
            
            // 重定向到原始URL
            header("Location: " . $urlData['original_url']);
            exit;
        } else {
            $pageTitle = "404 - 未找到";
            $error = "该短链接不存在或已过期";
        }
    } catch (Exception $e) {
        $pageTitle = "错误";
        $error = "处理请求时出错: " . $e->getMessage();
    }
}

// 获取统计数据
try {
    $stats = $urlManager->getStats();
} catch (Exception $e) {
    $stats = [
        'total_links' => 0,
        'total_clicks' => 0,
        'today_links' => 0
    ];
}

// 页面标题和描述
$pageTitle = isset($pageTitle) ? $pageTitle : "ShortLink - 简单高效的短链接服务";
$pageDescription = "ShortLink是一款简单高效的短链接生成工具，帮助您创建简洁、易记的短链接。";
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($pageTitle) ?></title>
    <meta name="description" content="<?= htmlspecialchars($pageDescription) ?>">
    <meta name="keywords" content="短链接,ShortLink,Link,链接缩短,短网址">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Tailwind 配置 -->
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: '#3B82F6',
                        secondary: '#10B981',
                        dark: {
                            primary: '#2563EB',
                            bg: '#111827',
                            card: '#1F2937',
                            text: '#F3F4F6'
                        }
                    },
                    fontFamily: {
                        inter: ['Inter', 'sans-serif'],
                    },
                    animation: {
                        'bounce-subtle': 'bounce-subtle 2s infinite',
                    },
                    keyframes: {
                        'bounce-subtle': {
                            '0%, 100%': { transform: 'translateY(0)' },
                            '50%': { transform: 'translateY(-5px)' },
                        }
                    }
                },
            }
        }
    </script>
    
    <style type="text/tailwindcss">
        @layer utilities {
            .content-auto {
                content-visibility: auto;
            }
            .shadow-custom {
                box-shadow: 0 10px 25px -5px rgba(59, 130, 246, 0.1), 0 8px 10px -6px rgba(59, 130, 246, 0.1);
            }
            .gradient-bg {
                background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
            }
            .glass-effect {
                backdrop-filter: blur(10px);
                background-color: rgba(255, 255, 255, 0.7);
            }
            .glass-effect-dark {
                backdrop-filter: blur(10px);
                background-color: rgba(31, 41, 55, 0.7);
            }
        }
    </style>
</head>

<body class="font-inter bg-gray-50 text-gray-800 dark:bg-dark-bg dark:text-dark-text min-h-screen transition-colors duration-300">
    <!-- 背景装饰 -->
    <div class="fixed inset-0 overflow-hidden -z-10">
        <div class="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/5 to-secondary/5 dark:from-primary/10 dark:to-secondary/10"></div>
        <div class="absolute -top-20 -right-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl dark:bg-primary/20"></div>
        <div class="absolute -bottom-20 -left-20 w-64 h-64 bg-secondary/10 rounded-full blur-3xl dark:bg-secondary/20"></div>
    </div>

    <header class="container mx-auto px-4 py-8 flex justify-between items-center">
        <div class="flex items-center space-x-2">
            <div class="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center text-white">
                <i class="fa-solid fa-link text-xl"></i>
            </div>
            <h1 class="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">
                ShortLink
            </h1>
        </div>
        
        <button id="themeToggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-card transition-colors">
            <i class="fa-solid fa-moon text-gray-600 dark:text-gray-300"></i>
        </button>
    </header>

    <main class="container mx-auto px-4 py-8 max-w-3xl">
        <div class="text-center mb-12">
            <h2 class="text-[clamp(2rem,5vw,3rem)] font-bold mb-4 leading-tight">
                缩短您的链接，<br class="md:hidden">拓展您的影响力
            </h2>
            <p class="text-gray-600 dark:text-gray-400 text-lg max-w-2xl mx-auto">
                简单高效的短链接生成工具，帮助您创建简洁、易记的短链接
            </p>
        </div>

        <!-- 主卡片 -->
        <div class="bg-white dark:bg-dark-card rounded-2xl shadow-custom p-6 md:p-8 transition-all duration-300 hover:shadow-lg">
            <!-- 错误/成功消息 -->
            <?php if (isset($error)): ?>
                <div class="mb-6 p-4 bg-red-50 dark:bg-red-900/30 rounded-lg border border-red-200 dark:border-red-700">
                    <div class="flex items-start">
                        <div class="flex-shrink-0 pt-0.5">
                            <i class="fa-solid fa-exclamation-circle text-red-500"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-red-800 dark:text-red-200">错误</h3>
                            <div class="mt-1 text-sm text-red-700 dark:text-red-300">
                                <?= $error ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <?php if (isset($success)): ?>
                <div class="mb-6 p-4 bg-green-50 dark:bg-green-900/30 rounded-lg border border-green-200 dark:border-green-700">
                    <div class="flex items-start">
                        <div class="flex-shrink-0 pt-0.5">
                            <i class="fa-solid fa-check-circle text-green-500"></i>
                        </div>
                        <div class="ml-3">
                            <h3 class="text-sm font-medium text-green-800 dark:text-green-200">成功</h3>
                            <div class="mt-1 text-sm text-green-700 dark:text-green-300">
                                <?= $success ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            
            <!-- 表单区域 -->
            <form id="shortenForm" method="POST" action="">
                <div class="relative">
                    <input 
                        id="url" 
                        name="url"
                        type="url" 
                        placeholder="请输入需要缩短的网址..." 
                        class="w-full px-5 py-4 rounded-xl border border-gray-200 dark:border-gray-700 focus:border-primary dark:focus:border-primary focus:ring-2 focus:ring-primary/20 dark:focus:ring-primary/30 dark:bg-gray-800 text-gray-800 dark:text-gray-200 transition-all outline-none placeholder-gray-400"
                        required
                    >
                    <div class="absolute right-4 top-1/2 -translate-y-1/2 hidden" id="urlLoader">
                        <i class="fa-solid fa-circle-notch fa-spin text-primary"></i>
                    </div>
                </div>
                
                <div class="mt-4 flex flex-col sm:flex-row gap-4">
                    <button 
                        type="submit"
                        id="submitBtn" 
                        class="flex-1 px-6 py-4 bg-primary hover:bg-primary/90 text-white font-medium rounded-xl transition-all duration-300 flex items-center justify-center gap-2 active:scale-98 focus:outline-none focus:ring-2 focus:ring-primary/30"
                    >
                        <i class="fa-solid fa-magic-wand-sparkles"></i>
                        <span>生成短链接</span>
                    </button>
                    
                    <button 
                        type="button"
                        id="customBtn" 
                        class="px-6 py-4 bg-gray-100 hover:bg-gray-200 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-700 dark:text-gray-200 font-medium rounded-xl transition-all duration-300 flex items-center justify-center gap-2 active:scale-98 focus:outline-none focus:ring-2 focus:ring-gray-300 dark:focus:ring-gray-500"
                    >
                        <i class="fa-solid fa-keyboard"></i>
                        <span>自定义</span>
                    </button>
                </div>
                
                <!-- 自定义短码输入 -->
                <div id="customCodeArea" class="mt-4 hidden">
                    <div class="flex">
                        <span class="bg-gray-100 dark:bg-gray-700 px-4 py-2 rounded-l-lg flex items-center text-gray-600 dark:text-gray-400">
                            <?= htmlspecialchars($_SERVER['HTTP_HOST']) ?>/
                        </span>
                        <input 
                            id="custom_code" 
                            name="custom_code"
                            type="text" 
                            class="flex-1 px-4 py-2 border border-gray-200 dark:border-gray-700 focus:border-primary dark:focus:border-primary focus:ring-2 focus:ring-primary/20 dark:focus:ring-primary/30 dark:bg-gray-800 text-gray-800 dark:text-gray-200 transition-all outline-none"
                            placeholder="自定义短码"
                            pattern="[a-zA-Z0-9_-]{3,20}"
                        >
                    </div>
                    <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">仅支持字母、数字、连字符和下划线，长度3-20个字符</p>
                </div>
            </form>
            
            <!-- 结果区域 -->
            <?php if (isset($success) && isset($shortUrl)): ?>
                <div id="resultArea" class="mt-6">
                    <div class="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 mb-6">
                        <div class="flex flex-col sm:flex-row gap-3">
                            <input 
                                id="shorturl" 
                                type="text" 
                                value="<?= htmlspecialchars($shortUrl) ?>"
                                readonly 
                                class="flex-1 bg-transparent border-none outline-none text-gray-800 dark:text-gray-200 font-medium text-lg"
                            >
                            <button 
                                id="copyBtn" 
                                class="px-4 py-2 bg-secondary hover:bg-secondary/90 text-white rounded-lg transition-all duration-300 flex items-center justify-center gap-2 active:scale-98"
                            >
                                <i class="fa-solid fa-copy"></i>
                                <span>复制</span>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- 统计卡片 -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
            <div class="bg-white dark:bg-dark-card rounded-xl p-6 shadow-custom transition-all duration-300 hover:shadow-lg">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300">总链接数</h3>
                    <div class="w-10 h-10 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                        <i class="fa-solid fa-link text-blue-500 dark:text-blue-400"></i>
                    </div>
                </div>
                <p class="text-3xl font-bold"><?= number_format($stats['total_links']) ?></p>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">已生成的短链接</p>
            </div>
            
            <div class="bg-white dark:bg-dark-card rounded-xl p-6 shadow-custom transition-all duration-300 hover:shadow-lg">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300">总点击量</h3>
                    <div class="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                        <i class="fa-solid fa-mouse-pointer text-green-500 dark:text-green-400"></i>
                    </div>
                </div>
                <p class="text-3xl font-bold"><?= number_format($stats['total_clicks']) ?></p>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">所有链接的点击次数</p>
            </div>
            
            <div class="bg-white dark:bg-dark-card rounded-xl p-6 shadow-custom transition-all duration-300 hover:shadow-lg">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-gray-700 dark:text-gray-300">今日新增</h3>
                    <div class="w-10 h-10 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                        <i class="fa-solid fa-calendar-day text-purple-500 dark:text-purple-400"></i>
                    </div>
                </div>
                <p class="text-3xl font-bold"><?= number_format($stats['today_links']) ?></p>
                <p class="text-sm text-gray-500 dark:text-gray-400 mt-1">今日生成的链接</p>
            </div>
        </div>
        
        <!-- 功能介绍 -->
        <div class="mt-16">
            <h2 class="text-2xl font-bold mb-8 text-center">为什么选择我们的短链接服务</h2>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <div class="bg-white dark:bg-dark-card rounded-xl p-6 shadow-custom transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                    <div class="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center text-white mb-4">
                        <i class="fa-solid fa-bolt text-xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">快速简洁</h3>
                    <p class="text-gray-600 dark:text-gray-400">瞬间生成短小精悍的链接，提升点击率和分享率。</p>
                </div>
                
                <div class="bg-white dark:bg-dark-card rounded-xl p-6 shadow-custom transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                    <div class="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center text-white mb-4">
                        <i class="fa-solid fa-chart-line text-xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">数据统计</h3>
                    <p class="text-gray-600 dark:text-gray-400">详细分析链接点击数据，了解受众行为和来源。</p>
                </div>
                
                <div class="bg-white dark:bg-dark-card rounded-xl p-6 shadow-custom transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
                    <div class="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center text-white mb-4">
                        <i class="fa-solid fa-lock text-xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">安全可靠</h3>
                    <p class="text-gray-600 dark:text-gray-400">所有链接均经过安全检查，确保您和用户的安全。</p>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-white dark:bg-dark-card mt-16 py-8">
        <div class="container mx-auto px-4">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="mb-6 md:mb-0">
                    <div class="flex items-center space-x-2 justify-center md:justify-start">
                        <div class="w-8 h-8 rounded-lg gradient-bg flex items-center justify-center text-white">
                            <i class="fa-solid fa-link"></i>
                        </div>
                        <span class="font-bold text-lg">ShortLink</span>
                    </div>
                    <p class="text-gray-600 dark:text-gray-400 text-sm mt-2 text-center md:text-left">
                        简单高效的短链接生成工具
                    </p>
                </div>
                
                <div class="flex space-x-6 mb-6 md:mb-0">
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary transition-colors">
                        <i class="fa-brands fa-github text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary transition-colors">
                        <i class="fa-brands fa-twitter text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-primary transition-colors">
                        <i class="fa-brands fa-weibo text-xl"></i>
                    </a>
                </div>
            </div>
            
            <div class="border-t border-gray-200 dark:border-gray-700 mt-6 pt-6 text-center text-gray-600 dark:text-gray-400 text-sm">
                <p>可爱的你 by <a href="https://cute.lv" class="hover:text-primary dark:hover:text-primary transition-colors">Cute</a>, 版权所有 萌ICP88888888</p>
            </div>
        </div>
    </footer>

    <!-- 通知提示 -->
    <div id="notification" class="fixed bottom-4 right-4 bg-white dark:bg-dark-card rounded-lg shadow-lg p-4 transform translate-y-20 opacity-0 transition-all duration-300 flex items-center gap-3 max-w-xs z-50">
        <div id="notificationIcon" class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
            <i class="fa-solid fa-check text-green-500"></i>
        </div>
        <div>
            <h4 id="notificationTitle" class="font-medium">操作成功</h4>
            <p id="notificationMessage" class="text-sm text-gray-600 dark:text-gray-400">链接已复制到剪贴板</p>
        </div>
    </div>

    <script>
        // 主题切换
        const themeToggle = document.getElementById('themeToggle');
        const html = document.documentElement;
        
        // 初始化主题
        if (localStorage.theme === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            html.classList.add('dark');
            themeToggle.innerHTML = '<i class="fa-solid fa-sun text-yellow-400"></i>';
        } else {
            html.classList.remove('dark');
            themeToggle.innerHTML = '<i class="fa-solid fa-moon text-gray-600"></i>';
        }
        
        // 切换主题
        themeToggle.addEventListener('click', () => {
            if (html.classList.contains('dark')) {
                html.classList.remove('dark');
                localStorage.theme = 'light';
                themeToggle.innerHTML = '<i class="fa-solid fa-moon text-gray-600"></i>';
            } else {
                html.classList.add('dark');
                localStorage.theme = 'dark';
                themeToggle.innerHTML = '<i class="fa-solid fa-sun text-yellow-400"></i>';
            }
        });
        
        // 自定义短码显示/隐藏
        const customBtn = document.getElementById('customBtn');
        const customCodeArea = document.getElementById('customCodeArea');
        
        customBtn.addEventListener('click', () => {
            customCodeArea.classList.toggle('hidden');
            
            // 如果显示自定义区域，自动聚焦
            if (!customCodeArea.classList.contains('hidden')) {
                document.getElementById('custom_code').focus();
            }
        });
        
        // 表单提交处理
        const shortenForm = document.getElementById('shortenForm');
        const submitBtn = document.getElementById('submitBtn');
        const urlLoader = document.getElementById('urlLoader');
        
        shortenForm.addEventListener('submit', () => {
            // 显示加载状态
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i><span>处理中...</span>';
            urlLoader.classList.remove('hidden');
        });
        
        // 复制到剪贴板
        const copyBtn = document.getElementById('copyBtn');
        
        copyBtn?.addEventListener('click', () => {
            const shorturl = document.getElementById('shorturl');
            shorturl.select();
            document.execCommand('copy');
            
            // 显示复制成功提示
            showNotification('链接已复制到剪贴板', '成功');
        });
        
        // 显示通知
        function showNotification(message, type = 'success') {
            const notification = document.getElementById('notification');
            const notificationIcon = document.getElementById('notificationIcon');
            const notificationTitle = document.getElementById('notificationTitle');
            const notificationMessage = document.getElementById('notificationMessage');
            
            // 设置通知内容和样式
            notificationMessage.textContent = message;
            
            if (type === 'success') {
                notificationTitle.textContent = '操作成功';
                notificationIcon.className = 'w-8 h-8 rounded-full bg-green-100 flex items-center justify-center';
                notificationIcon.innerHTML = '<i class="fa-solid fa-check text-green-500"></i>';
            } else {
                notificationTitle.textContent = '操作失败';
                notificationIcon.className = 'w-8 h-8 rounded-full bg-red-100 flex items-center justify-center';
                notificationIcon.innerHTML = '<i class="fa-solid fa-exclamation text-red-500"></i>';
            }
            
            // 显示通知
            notification.classList.remove('translate-y-20', 'opacity-0');
            
            // 3秒后自动隐藏
            setTimeout(() => {
                notification.classList.add('translate-y-20', 'opacity-0');
            }, 3000);
        }
    </script>
</body>
</html>