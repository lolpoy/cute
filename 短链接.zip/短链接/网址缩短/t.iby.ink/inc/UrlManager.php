<?php
class UrlManager {
    private $pdo;
    
    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->createTable();
    }
    
    // 创建数据表（如果不存在）
    private function createTable() {
        $sql = "CREATE TABLE IF NOT EXISTS urls (
            id INT AUTO_INCREMENT PRIMARY KEY,
            short_code VARCHAR(20) UNIQUE NOT NULL,
            original_url TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            clicks INT DEFAULT 0
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        $this->pdo->exec($sql);
    }
    
    // 生成唯一短码
    public function generateUniqueCode() {
        $code = '';
        $charset = CHARSET;
        $length = strlen($charset);
        $codeLength = CODE_LENGTH;
        
        // 生成随机字符串
        do {
            $code = '';
            for ($i = 0; $i < $codeLength; $i++) {
                $code .= $charset[random_int(0, $length - 1)];
            }
        } while ($this->codeExists($code));
        
        return $code;
    }
    
    // 检查短码是否已存在
    public function codeExists($code) {
        $stmt = $this->pdo->prepare("SELECT id FROM urls WHERE short_code = ?");
        $stmt->execute([$code]);
        return $stmt->fetch() !== false;
    }
    
    // 根据原始URL获取记录
    private function getUrlByOriginal($originalUrl) {
        $stmt = $this->pdo->prepare("SELECT short_code FROM urls WHERE original_url = ? LIMIT 1");
        $stmt->execute([$originalUrl]);
        return $stmt->fetch();
    }
    
    // 创建短链接（如果URL已存在则返回现有短码）
    public function createShortUrl($originalUrl, $customCode = null) {
        // 先检查URL是否已存在
        $existingUrl = $this->getUrlByOriginal($originalUrl);
        
        if ($existingUrl) {
            // URL已存在，直接返回现有短链接
            return BASE_URL . $existingUrl['short_code'];
        }
        
        // URL不存在，生成新短码
        if ($customCode) {
            // 检查自定义短码是否可用
            if ($this->codeExists($customCode)) {
                throw new Exception("自定义短码 '{$customCode}' 已被使用");
            }
            $shortCode = $customCode;
        } else {
            // 生成随机短码
            $shortCode = $this->generateUniqueCode();
        }
        
        // 插入新记录
        $stmt = $this->pdo->prepare("INSERT INTO urls (short_code, original_url) VALUES (?, ?)");
        $stmt->execute([$shortCode, $originalUrl]);
        
        // 返回完整短链接
        return BASE_URL . $shortCode;
    }
    
    // 根据短码获取原始URL
    public function getUrlByCode($shortCode) {
        $stmt = $this->pdo->prepare("SELECT original_url, clicks FROM urls WHERE short_code = ?");
        $stmt->execute([$shortCode]);
        return $stmt->fetch();
    }
    
    // 增加点击计数
    public function incrementClickCount($shortCode) {
        $stmt = $this->pdo->prepare("UPDATE urls SET clicks = clicks + 1 WHERE short_code = ?");
        $stmt->execute([$shortCode]);
    }
    
    // 获取统计数据
    public function getStats() {
        $stats = [];
        
        // 总链接数
        $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM urls");
        $stats['total_links'] = (int)$stmt->fetchColumn();
        
        // 总点击量
        $stmt = $this->pdo->query("SELECT SUM(clicks) as total FROM urls");
        $stats['total_clicks'] = (int)$stmt->fetchColumn();
        
        // 今日新增
        $today = date('Y-m-d');
        $stmt = $this->pdo->prepare("SELECT COUNT(*) as total FROM urls WHERE DATE(created_at) = ?");
        $stmt->execute([$today]);
        $stats['today_links'] = (int)$stmt->fetchColumn();
        
        return $stats;
    }
}