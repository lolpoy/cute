<?php
// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'jaaman');//替换数据库名
define('DB_USER', 'jaaman');//替换数据库用户名
define('DB_PASSWORD', 'jaaman'); // 替换为实际数据库密码

// 应用配置
define('BASE_URL', 'http://t.iby.ink/'); // 替换为您的域名
define('CODE_LENGTH', 3); // 短码长度
define('CHARSET', 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'); // 可用字符集