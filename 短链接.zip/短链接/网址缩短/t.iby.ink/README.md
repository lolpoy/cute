# ShortLink

**简体中文** | [English](./README.en.md)

代码基于 [CRZ.im](https://github.com/Caringor/CRZ.im) 二次开发，感谢原作者的辛勤劳动。

## 概述

这是一个网址缩短服务的网站的源代码。

## 安装

### 环境准备

+ 兼容 PHP 7.x
+ `Nginx 1.15+`
+ ~~`MySQL 5.5+`

提示：若访问量较大，建议安装在具有SSD硬盘的服务器上。

### 配置修改

修改 `config.php` 里面的 数据库，用户名，密码等相关配置 并把 `inc` 目录权限设置为 `755` 即可。

### URL 重写规则

#### Nginx 用户

需要把 `nginx-rewrite.conf` 里面的内容添加到 `Nginx` 对欲使用网站的配置文件里。

## 功能

+ 长链转短链
+ 界面简洁
+ 一键复制


